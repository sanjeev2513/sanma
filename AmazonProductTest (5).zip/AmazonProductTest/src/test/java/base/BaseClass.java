package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {

	public static WebDriver driver;
	static String res;

	public void getUrl(String url) {
		driver.get(url);
	}

	public void maximize() {
		driver.manage().window().maximize();
	}

	public void implicitWait() {
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	}

	public String getPropertyFileValue(String key) throws IOException, Throwable {
		Properties properties = new Properties();
		FileInputStream stream = new FileInputStream((System.getProperty("user.dir") + "\\config\\config.properties"));
		properties.load(stream);
		String string = (String) properties.get(key);
		return string;
	}

	public void getBrowser(String type) {
		switch (type) {
		case "chrome":
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			break;
		case "firefox":
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			break;
		case "edge":
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
			break;

		default:
			break;
		}
	}

	public void sendkeys(WebElement element, String data) {
		element.sendKeys(data);
	}

	public String getText(WebElement element) {
		String text = element.getText();
		return text;
	}

	public String getWinId() {
		String PrntWinId = driver.getWindowHandle();
		return PrntWinId;
	}

	public Set<String> getAllWinId() {
		Set<String> allWinId = driver.getWindowHandles();
		return allWinId;
	}

	public void moveToChildWinId(String prntWinId, Set<String> allWinId) {
		for (String childId : allWinId) {
			if (!(prntWinId.equals(childId))) {
				driver.switchTo().window(childId);
			}
		}

	}

	public String getCellData(String sheetName, int rowNo, int cellNo) throws IOException {
		String res = null;
		File file = new File(
				"C:\\Users\\mohan\\eclipse-workspace\\AmazonProductTest\\src\\test\\resources\\TestDataSheet\\Book1.xlsx");
		FileInputStream stream = new FileInputStream(file);
		Workbook workbook = new XSSFWorkbook(stream);
		Sheet sheet = workbook.getSheet(sheetName);
		Row row = sheet.getRow(rowNo);
		Cell cell = row.getCell(cellNo);
		res = cell.getStringCellValue();
		return res;
	}

	public void quitDriver() {
		driver.quit();
	}

}
