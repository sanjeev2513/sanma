package pom;

import pages.HomePage;
import pages.ProductPage;

public class PageObjectManager {

	private HomePage homePage;
	private ProductPage productPage;

	public HomePage getHomePage() {
		return (homePage == null) ? homePage = new HomePage() : homePage;
	}

	public ProductPage getProductPage() {
		return (productPage == null) ? productPage = new ProductPage() : productPage;
	}

}
