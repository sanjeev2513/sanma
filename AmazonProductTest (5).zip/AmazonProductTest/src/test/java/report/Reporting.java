package report;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

public class Reporting {

	public static void generateJVMReport(String jsonfile) {

		File file = new File(System.getProperty("user.dir") + "\\target");

		Configuration configuration = new Configuration(file, "AmazonProductTest");

		configuration.addClassifications("Browser", "Chrome");
		configuration.addClassifications("Browser Verson", "104");
		configuration.addClassifications("OS", "Windows 11");
		configuration.addClassifications("Sprint", "25");

		List<String> jsonFiles = new ArrayList<String>();
		jsonFiles.add(jsonfile);

		ReportBuilder builder = new ReportBuilder(jsonFiles, configuration);

		builder.generateReports();
	}

}
