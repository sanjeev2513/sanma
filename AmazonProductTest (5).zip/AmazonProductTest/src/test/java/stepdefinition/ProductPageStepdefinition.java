package stepdefinition;

import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.PageObjectManager;

public class ProductPageStepdefinition extends BaseClass {

	PageObjectManager pom = new PageObjectManager();

	@When("I want click the first product and go to child window")
	public void i_want_click_the_first_product_and_go_to_child_window() {
		pom.getProductPage().getFirstProduct().click();
		String prntWinId = getWinId();
		Set<String> allWinId = getAllWinId();
		moveToChildWinId(prntWinId, allWinId);
	}

	@When("I want to add that product to cart")
	public void i_want_to_add_that_product_to_cart() {
		pom.getProductPage().getAddToCartButton().click();
	}

	@Then("I want to validate the product which was added")
	public void i_want_to_validate_the_product_which_was_added() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, 5000);
		wait.until(ExpectedConditions.visibilityOf(pom.getProductPage().getAddedToCart()));
		Assert.assertTrue(pom.getProductPage().getAddedToCart().isDisplayed());
	}

}
