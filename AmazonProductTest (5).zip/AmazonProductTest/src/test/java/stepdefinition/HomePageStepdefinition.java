package stepdefinition;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import pom.PageObjectManager;

public class HomePageStepdefinition extends BaseClass {

	PageObjectManager pom = new PageObjectManager();

	@Given("I am in home page")
	public void i_am_in_home_page() throws IOException, Throwable {
		getBrowser(getPropertyFileValue("browser"));
		getUrl(getPropertyFileValue("HomePageUrl"));
	}

	@When("I want to search the specific product")
	public void i_want_to_search_the_specific_product() throws IOException {
		pom.getHomePage().searchProduct(getCellData("TestSheet1", 0, 0));
	}

}
