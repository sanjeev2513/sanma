package stepdefinition;

import java.io.IOException;

import base.BaseClass;

public class Hooks extends BaseClass {

	public void browserLaunch() throws IOException, Throwable {
		getBrowser(getPropertyFileValue("browser"));
	}

	public void quitBrowser() {
		quitDriver();
	}

}
