package runner;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import report.Reporting;

@RunWith(Cucumber.class)
@CucumberOptions(dryRun = false, features = "src\\test\\resources", glue = "stepdefinition", stepNotifications = true, monochrome = true, publish = true, plugin = {
		"pretty", "json:target/output.json" })
public class TestRunner {

	@AfterClass
	public static void afterClass() {

		Reporting.generateJVMReport(System.getProperty("user.dir") + "\\target\\Output.json");

	}

}
