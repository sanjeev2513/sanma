package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.BaseClass;

public class ProductPage extends BaseClass {

	public ProductPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//span[text()='Apple iPhone 13 (128GB) - Starlight']")
	private WebElement firstProduct;

	@FindBy(xpath = "//input[@id='add-to-cart-button']")
	private WebElement addToCartButton;

	@FindBy(xpath = "//div[@id='attachDisplayAddBaseAlert']")
	private WebElement addedToCart;

	public WebElement getFirstProduct() {
		return firstProduct;
	}

	public WebElement getAddToCartButton() {
		return addToCartButton;
	}

	public WebElement getAddedToCart() {
		return addedToCart;
	}

}
